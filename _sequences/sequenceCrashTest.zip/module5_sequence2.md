---
title: "Débrief de la formation"
numeroSequence: 2
numeroModule: 5
numeroEdition:
    - 1
type: "autre"
description: "Un temps d'échanges entre tous les participants et les formateurs"
temps: 45 minutes

formateurs : 
 - fredericdeLamotte
 - gauthierSarah
 - heleneChiapello
 - jeanfrancoisDufayard
 - julienSeiler
 - pauletteLieby
 - thomasdenecker

---

{% include repoImage.html pathInRepo="/assets/img/divers/reunion.jpg" %}

