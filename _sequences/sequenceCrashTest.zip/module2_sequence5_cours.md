---
title: "Outils et solution"
numeroSequence: 5
numeroModule: 2
numeroEdition:
    - 1
type: "cours"
description: "Au cours de cette présentation vous découvrirez la solution osf.io, l'outil Git et gitlab.com ainsi que l'infrastructure Core Cluster de l'IFB"
temps: 15 minutes

formateurs :
 - fredericdeLamotte
 - julienSeiler

---

{% include pdf.html adresse="assets/PDFs/edition1/Module2/Module2_sequence5.pdf" local="true" %}
