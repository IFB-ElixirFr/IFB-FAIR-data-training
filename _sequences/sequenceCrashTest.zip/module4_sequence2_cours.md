---
title: "Les licences sur les données"
numeroSequence: 2
numeroModule: 4
numeroEdition:
    - 1
type: "cours"
description: "Les licences sur les données"
temps: 30 minutes

formateurs : 
 - fredericdeLamotte
 - pauletteLieby

---


{% include pdf.html adresse="/assets/PDFs/edition1/Module4/Module4_sequence2_cours.pdf" local="true" %}
