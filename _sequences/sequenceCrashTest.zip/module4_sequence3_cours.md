---
title: "Quel entrepôt pour quelles données ?"
numeroSequence: 3
numeroModule: 4
numeroEdition:
    - 1
type: "cours"
description: "Quel entrepôt pour quelles données ?"
temps: 30 minutes

formateurs : 
    - heleneChiapello
    - thomasdenecker
    - jeanfrancoisDufayard
    - gauthierSarah
    - fredericdeLamotte
    - pauletteLieby
    - julienSeiler

---

{% include repoImage.html pathInRepo="assets/img/divers/WIP.png" %}