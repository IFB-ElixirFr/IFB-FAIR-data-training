---
title: "Le nommage des fichiers"
numeroSequence: 2
numeroModule: 2
numeroEdition:
    - 1
type: "cours"
description: "L'objectif de ce cours est de comprendre pourquoi le nommage des fichiers est si important et des pistes pour mieux nommer ses fichiers."
temps: 10 minutes

formateurs :
 - fredericdeLamotte
 - julienSeiler
---

{% include pdf.html adresse="assets/PDFs/edition1/Module2/Module2_sequence2.pdf" local="true" %}
