---
title: "Quizz"
numeroSequence: 3
numeroModule: 5
numeroEdition:
    - 1
type: "autre"
description: "Un petit quizz pour tester vos connaissances après cette formation."
temps: 45 minutes

formateurs : 
 - fredericdeLamotte
 - gauthierSarah
 - heleneChiapello
 - jeanfrancoisDufayard
 - julienSeiler
 - pauletteLieby
 - thomasdenecker

---

## Questionnaire

{% include repoImage.html pathInRepo="/assets/img/divers/quizz.jpeg" %}

Un petit quizz pour tester vos connaissances après cette formation.

Lien vers le quizz : 