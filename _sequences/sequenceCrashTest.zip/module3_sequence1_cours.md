---
title: " Introduction aux métadonnées"
numeroSequence: 1
numeroModule: 3
numeroEdition:
    - 1
type: "cours"
description: "L'objectif d'avoir un aperçu des métadonnées"
temps: 20 minutes

formateurs : 
 - fredericdeLamotte
  
---

{% include pdf.html adresse="/assets/PDFs/edition1/Module3/Module3_Sequence1.pdf" local="true" %}
