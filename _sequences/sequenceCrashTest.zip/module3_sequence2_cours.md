---
title: "Life science standards and ENA submission"
numeroSequence: 2
numeroModule: 3
numeroEdition:
    - 1
type: "cours"
description: "L'objectif d'avoir un aperçu des standards en Life science et comment soumettre sur l'ENA"
temps: 20 minutes

formateurs : 
 - heleneChiapello
  
---

{% include pdf.html adresse="/assets/PDFs/edition1/Module3/Module3_sequence2_cours.pdf" local="true" %}
