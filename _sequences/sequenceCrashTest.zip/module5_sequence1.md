---
title: "Fin du PGD"
numeroSequence: 1
numeroModule: 5
numeroEdition:
    - 1
type: "autre"
description: "L'objectif de terminer son PGD"
temps: 45 minutes

formateurs : 
 - fredericdeLamotte
 - gauthierSarah
 - heleneChiapello
 - jeanfrancoisDufayard
 - julienSeiler
 - pauletteLieby
 - thomasdenecker

---


