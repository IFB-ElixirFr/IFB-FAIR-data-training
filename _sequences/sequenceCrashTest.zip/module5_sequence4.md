---
title: "Questionnaire"
numeroSequence: 4
numeroModule: 5
numeroEdition:
    - 1
type: "autre"
description: "Questionnaire"
temps: 10 minutes

formateurs : 
    - heleneChiapello
    - thomasdenecker
    - jeanfrancoisDufayard
    - gauthierSarah
    - fredericdeLamotte
    - pauletteLieby
    - julienSeiler


---

## Questionnaire sur les 4 premiers modules de formation

[![quiz](https://image.freepik.com/vecteurs-libre/quiz-dans-style-bande-dessinee-pop-art_175838-505.jpg)](https://forms.gle/uKnXtvdGA2oPsux27){:target="_blank"}

Lien vers le quizz : [ici](https://forms.gle/uKnXtvdGA2oPsux27){:target="_blank"} ou cliquer sur l'image ! 