---
title: "Format de fichier"
numeroSequence: 3
numeroModule: 2
numeroEdition:
    - 1
type: "cours"
description: "L'objectif de ce cours de mieux comprendre les formats de fichier."
temps: 15 minutes

formateurs :
 - fredericdeLamotte
 - julienSeiler

---

{% include pdf.html adresse="assets/PDFs/edition1/Module2/Module2_sequence3.pdf" local="true" %}
