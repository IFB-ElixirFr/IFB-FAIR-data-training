---
title: "Introduction"
numeroSequence: 1
numeroModule: 2
numeroEdition:
    - 1
type: "tp"
description: "Point de situation et exercice sur la vie des données"
temps: 40 minutes

formateurs :
 - fredericdeLamotte
 - julienSeiler
---

{% include pdf.html adresse="assets/PDFs/edition1/Module2/Module2_sequence1.pdf" local="true" %}
