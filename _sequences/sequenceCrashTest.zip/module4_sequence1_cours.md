---
title: "Cadre Juridique "
numeroSequence: 1
numeroModule: 4
numeroEdition:
    - 1
type: "cours"
description: "Cadre Juridique "
temps: 2 heures

formateurs : 
 - lionelMaurel

---

## Cours 

{% include pdf.html adresse="/assets/PDFs/edition1/Module4/module4_sequence1_LM.pdf" local="true" %}

## Logigrammes

{% include pdf.html adresse="/assets/PDFs/edition1/Module4/Ouverture_Donnees_INRAe_Decision.pdf" local="true" %}
