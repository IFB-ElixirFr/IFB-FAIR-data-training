---
title: "Stockage et accès"
numeroSequence: 4
numeroModule: 2
numeroEdition:
    - 1
type: "cours"
description: "L'objectif de ce cours est de comprendre les enjeux et les bonnes pratiques dans l'utilisation des solutions stockages et la gestion de leurs accès"
temps: 20 minutes

formateurs :
 - fredericdeLamotte
 - julienSeiler

---

{% include pdf.html adresse="assets/PDFs/edition1/Module2/Module2_sequence4.pdf" local="true" %}
