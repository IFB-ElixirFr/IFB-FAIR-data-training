---
title: Module 4
header_title: Module 4
header_subTitle: "Partager et diffuser les données. Le cadre juridique, les entrepôts et les licences sur les données"
numeroModule : 4

timeStart: "20-01-2021 09:00"
timeEnd: "20-01-2021 12:00"
timezone: "Europe/Paris"

fomulaireAvis: "https://forms.gle/Wmx91tbyyt3w985V8"
---

