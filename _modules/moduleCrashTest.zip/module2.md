---
title: Module 2
header_title: Module 2
header_subTitle: "La vie des données pendant le projet : Principe et outils pour organiser, nommer, versionner, stocker, archiver, mes données"
numeroModule : 2

timeStart: "14-01-2021 09:00"
timeEnd: "14-01-2021 12:00"
timezone: "Europe/Paris"

homework:
    - "Créer un compte sur l'ENA (prod) : [ici](https://www.ebi.ac.uk/ena/submit/webin/accountInfo)"

fomulaireAvis: "https://forms.gle/YjjLaNLMNyCEGRtQ9"
---

## Slide du module

<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vRC8g3Y1QU0qObgbUgxpmIvjrqEQLxfBjoCys55owPRUkC0Esvpt2iweg25kGdQtA/embed?start=false&loop=false&delayms=3000" frameborder="0" width="100%" height="569" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>
