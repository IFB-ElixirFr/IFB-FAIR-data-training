---
title: Module 3
header_title: Module 3
header_subTitle: "Les Métadonnées : les standards du domaine des données omiques en biologie et séances pratiques d’annotations de jeux de données"
numeroModule : 3

timeStart: "15-01-2021 09:00"
timeEnd: "15-01-2021 12:00"
timezone: "Europe/Paris"

fomulaireAvis: "https://forms.gle/xz87fWdCMHy2s28y8"
---
