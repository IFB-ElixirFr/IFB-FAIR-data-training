---
title: Module 1
header_title: Module 1
header_subTitle: Les données de la Recherche et leur centralité dans le processus de recherche
numeroModule : 1

timeStart: "13-01-2021 09:00"
timeEnd: "13-01-2021 12:00"
timezone: "Europe/Paris"

questions:
    - Quelle définition pour les données de la recherche ? 
    - Quelles seraient les conditions pour que les données soient (ré)utilisables ?

homework:
    - Créer un compte sur DMP OPIDoR
    - Créer et ouvrir un Plan de Gestion des Données basé sur le modèle choisi (mode entraînement)
    - Inviter les formateurs comme collaborateurs

fomulaireAvis: "https://forms.gle/nX8UrxsJmzYvSzEt5"
---

## Slide du module

<iframe src="https://docs.google.com/presentation/d/e/2PACX-1vTK6uqomlk3kP6h-_0l-qHfOM37UQer06NWs4f1h9WznYhQevfe13BYuO0mMN9Q5tIPIpTtNdwFwpqg/embed?start=false&loop=false&delayms=3000" frameborder="0" width="100%" height="569" allowfullscreen="true" mozallowfullscreen="true" webkitallowfullscreen="true"></iframe>